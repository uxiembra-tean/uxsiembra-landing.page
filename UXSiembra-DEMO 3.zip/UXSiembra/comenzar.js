/* FORMULARIO REGISTRARSE */
document.addEventListener("DOMContentLoaded", () => {
  const formulario = document.getElementById("formularioContacto");

  formulario.addEventListener("submit", (event) => {
    event.preventDefault(); // Evita el envío normal del formulario

    // Obtener valores de los campos
    const nombres = document.getElementById("nombres").value.trim();
    const apellidos = document.getElementById("apellidos").value.trim();
    const contrasena = document.getElementById("contrasena").value.trim();
    const tipoDoc = document.getElementById("tipoDoc").value;
    const documento = document.getElementById("Documento").value.trim();
    const telefono = document.getElementById("telefono").value.trim();
    const pais = document.getElementById("pais").value;
    const email = document.getElementById("email").value.trim();

    // Validaciones básicas
    if (!nombres || !apellidos || !contrasena || !documento || !email) {
      alert("Por favor completa todos los campos obligatorios ❗");
      return;
    }

    // Validar formato del correo electrónico
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      alert("Por favor ingresa un correo electrónico válido ❗");
      return;
    }

    // Validar contraseña (ejemplo simple)
    if (contrasena.length < 6) {
      alert("La contraseña debe tener al menos 6 caracteres ❗");
      return;
    }

    // Crear un objeto con los datos del usuario (puede guardarse en localStorage o enviarse a servidor)
    const usuario = {
      nombres,
      apellidos,
      contrasena,
      tipoDoc,
      documento,
      telefono,
      pais,
      email
    };

    // Guardar en localStorage (simula un registro temporal)
    localStorage.setItem("usuarioRegistrado", JSON.stringify(usuario));

    // Confirmación
    alert("✅ Registro exitoso. Serás redirigido a la página de inicio de sesión.");

    // Redirección a iniciar.html
    window.location.href = "iniciar.html";
  });
});